import GuessGame, MemoryGame, CurrencyRouletteGame
games_amount = 3
max_difficulty = 5


def number_check(num, max_number):
    try:
        num = int(num)
        if 0 < num < (max_number + 1):
            return True
        else:
            return False
    except:
        return False


def welcome(name):
    return "Hello %s and welcome to the World of Games (WoG). \nHere you can find many cool games to play." % name


def load_game():
    print("Please choose a game to play: \n"
          "\t 1. Memory Game - a sequence of numbers will appear for 1 second and you have to guess it back"
          "\n\t 2. Guess Game - guess a number and see if you chose like the computer"
          "\n\t 3. Currency Roulette - try and guess the value of a random amount of USD in ILS")
    chosen_game = input(f"Please choose game! enter number between 1-{games_amount} - ")
    input_check = number_check(chosen_game, games_amount)
    while not input_check:
        chosen_game = input(f"You need to enter A  CORRECT NUMBER!  Please enter number between 1-{games_amount} - ")
        input_check = number_check(chosen_game, games_amount)
    difficulty = input(f"Great! Please choose the game difficulty. Enter number between 1 - {max_difficulty} :  ")
    input_check = number_check(difficulty, max_difficulty)
    while not input_check:
        difficulty = input(f"You need to enter A  CORRECT NUMBER!  Please enter number between 1-{max_difficulty} - ")
        input_check = number_check(difficulty, max_difficulty)
    chosen_game = int(chosen_game)
    difficulty = int(difficulty)
    start_game(chosen_game, difficulty)


def start_game(chosen_game, difficulty):
    if chosen_game == 1:
        MemoryGame.play(difficulty)
    elif chosen_game == 2:
        GuessGame.play(difficulty)
    elif chosen_game == 3:
        CurrencyRouletteGame.play(difficulty)
